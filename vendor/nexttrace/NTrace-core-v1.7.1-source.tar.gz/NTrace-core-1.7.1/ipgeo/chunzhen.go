package ipgeo

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/nxtrace/NTrace-core/util"
)

func Chunzhen(ip string, timeout time.Duration, _ string, _ bool) (*IPGeoData, error) {
	url := util.GetEnvDefault("NEXTTRACE_CHUNZHENURL", "http://127.0.0.1:2060") + "?ip=" + ip
	client := util.NewGeoHTTPClient(timeout)
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return &IPGeoData{}, fmt.Errorf("chunzhen: failed to create request: %w", err)
	}
	content, err := client.Do(req)
	if err != nil {
		log.Println("纯真 请求超时(2s)，请切换其他API使用")
		return &IPGeoData{}, err
	}
	defer content.Body.Close()
	body, err := io.ReadAll(content.Body)
	if err != nil {
		return &IPGeoData{}, fmt.Errorf("chunzhen: failed to read response: %w", err)
	}

	var data map[string]interface{}
	err = json.Unmarshal(body, &data)
	if err != nil {
		return &IPGeoData{}, err
	}
	ipData, ok := data[ip].(map[string]interface{})
	if !ok {
		return &IPGeoData{}, fmt.Errorf("chunzhen: unexpected response format for ip %s", ip)
	}
	city, _ := ipData["area"].(string)
	region, _ := ipData["country"].(string)
	var asn string
	if ipData["asn"] != nil {
		asn, _ = ipData["asn"].(string)
	}
	// 判断是否前两个字为香港或台湾
	var country string
	provinces := []string{
		"北京",
		"天津",
		"河北",
		"山西",
		"内蒙古",
		"辽宁",
		"吉林",
		"黑龙江",
		"上海",
		"江苏",
		"浙江",
		"安徽",
		"福建",
		"江西",
		"山东",
		"河南",
		"湖北",
		"湖南",
		"广东",
		"广西",
		"海南",
		"重庆",
		"四川",
		"贵州",
		"云南",
		"西藏",
		"陕西",
		"甘肃",
		"青海",
		"宁夏",
		"新疆",
		"台湾",
		"香港",
		"澳门",
	}
	for _, province := range provinces {
		if strings.Contains(region, province) {
			country = "中国"
			city = region + city
			break
		}
	}
	if country == "" {
		country = region
	}
	return &IPGeoData{
		Asnumber: asn,
		Country:  country,
		City:     city,
	}, nil
}
